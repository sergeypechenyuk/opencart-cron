<?php
// example: 
// $cron->call("module/ocstore_badges/cron", array ("minute" => "*", "hour" => "*", "day" => "*", "dayofweek" => "*", "dayofmonth" => "*"));
 
//end file