<?php
// example: 
//$cron->call("module/yourmodulename/method", array ("minute" => "*", "hour" => "*", "day" => "*", "dayofweek" => "*", "dayofmonth" => "*"), array("param" => true));
 
//end file